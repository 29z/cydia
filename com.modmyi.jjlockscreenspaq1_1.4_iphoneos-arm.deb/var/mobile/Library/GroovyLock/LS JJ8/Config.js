/*
Configuration here !
Code by Dacal -- Modified by Schnedi  // D0 NOT REMOVE THIS LINE //
*/

var lang = "sp";	       // choose between "sp", "en", "de", "fr" or "it".