switch (lang) {
case "fr":
	var days = ["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];
	var months=['Janvier','Fevrier','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Decembre'];
break;
case "de":
	var days = ["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"];
	var months=["Januar","Februar","Marz","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];		
break;
case "sp":
	var days = ["Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado"];
	var months=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
break;
case "it":
	var days = ["Domenica","Lunedi","Martedi","Mercoledi","Giovedi","Venerdi","Sabato"];
	var months=['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'];
break;
default: 
	var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
	var months=["January","February","March","April","May","June","July","August","September","October","November","December"];
break;
}

function updateClock() { 
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
var currentYear = currentTime.getFullYear();
timeOfDay = ( currentHours < 12 ) ? "a.m." : "p.m.";

if (lang == "en"){
var currentHours_name_array = new Array ("Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve")}
if (lang == "fr"){
var currentHours_name_array = new Array ("minuit", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix", "onze", "midi", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix", "onze", "minuit")}
if (lang == "de"){
var currentHours_name_array = new Array ("null", "ein", "zwei", "drei", "vier", "f¸nf", "sechs", "sieben", "acht", "neun", "zehn", "elf", "zwˆlf", "dreizehn", "vierzehn", "f¸nfzehn", "sechzehn", "siebzehn", "achtzehn", "neunzehn", "zwanzig", "einundzwanzig", "zweiundzwanzig", "dreiundzwanzig", "null")}
if (lang == "sp"){
var currentHours_name_array = new Array ("doce", "una", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez", "once", "doce", "una", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez", "once", "doce")}
if (lang == "it"){
var currentHours_name_array = new Array ("mezzanotte", "una", "due", "tre", "quattro", "cinque", "sei", "sette", "otto", "nove", "dieci", "undici", "mezzogiorno", "una", "due", "tre", "quattro", "cinque", "sei", "sette", "otto", "nove", "dieci", "undici", "mezzanotte")}

currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
currentHours = ( currentHours == 0 ) ? 12 : currentHours;
currentTimeString = currentHours + ":" + currentMinutes;
document.getElementById("hour").innerHTML = currentHours;
document.getElementById("minute").innerHTML = currentMinutes;
document.getElementById("ampm").innerHTML = timeOfDay;

document.getElementById("hour").innerHTML = currentHours_name_array[currentHours];

document.getElementById("weekday").innerHTML = days[currentTime.getDay()];
document.getElementById("date").innerHTML = currentDate;
document.getElementById("month").innerHTML = months[currentTime.getMonth()];
document.getElementById("year").innerHTML = currentYear;
}

function my_cal()
{
if (lang == "fr"){
var days_sett = new Array('d','l','m','m','j','v','s','d');
}
if (lang == "de"){
var days_sett = new Array('s','m','d','m','d','f','s','s');
}
if (lang == "it"){
var days_sett = new Array('d','l','m','m','g','v','s','d');
}
if (lang == "sp"){
var days_sett = new Array('d','l','m','m','j','v','s','d');
}
if (lang == "en"){
var days_sett = new Array('s','m','t','w','t','f','s','s');
}

var month_year = new Array('January','Feburary','March','April','May','June','July','August','September','October','November','December');
var days_month = new Array(31,28,31,30,31,30,31,31,30,31,30,31);
var Calendar = new Date();
var Clock = new Date();
var year = Calendar.getFullYear();	//year
var month = Calendar.getMonth();		//month (by 0 to 11)
var today = Calendar.getDate(); 	//numero day (by 1 to 31)
var day = Calendar.getDay();		//day settimana (by 0 to 6)
var time_clock = Clock.getHours();
var time_minute = Clock.getMinutes();
var time_second = Clock.getSeconds();
var num_days = 7;
var day;
var cal;
var clock = time_clock;
var PM_AM = 'AM';

cal =  '<TABLE CELLPADDING="0" CELLSPACING="0" BORDER="0"><TR>';

if(time_clock > 12)
	clock = time_clock-12;
else if(time_clock <= 0)
	clock = time_clock+12;

if(clock < 10 & time_minute < 10)
	cal += '<TD ROWSPAN="3" CLASS="clock">0' + clock + ':0' + time_minute + '</TD>';
else if(clock > 9 & time_minute < 10)
	cal += '<TD ROWSPAN="3" CLASS="clock">' + clock + ':0' + time_minute + '</TD>';
else if(clock < 10 & time_minute > 9)
	cal += '<TD ROWSPAN="3" CLASS="clock">0' + clock + ':' + time_minute + '</TD>';
else if(clock > 9 & time_minute > 9)
	cal += '<TD ROWSPAN="3" CLASS="clock">' + clock + ':' + time_minute + '</TD>';

if(time_clock > 11)
	PM_AM = 'PM';

if(time_second < 10)
	cal += '<TD ROWSPAN="3" CLASS="second">:0' + time_second + '<br />' + PM_AM + '</TD>';
else
	cal += '<TD ROWSPAN="3" CLASS="second">:' + time_second + '<br />' + PM_AM + '</TD>';
cal += '</TR><TR><TD CLASS="month">' + month_year[month] + '</TD></TR><TR><TD CLASS="year">' + year + '</TD></TR></TABLE>';
cal +=	'<TABLE CELLPADDING="0" CELLSPACING="0" BORDER="0"><TR>';

var day = day;
for(index=0; index < num_days; index++) {
	if (day == index)
		cal += '<TD CLASS="days_s">' + days_sett[index] + '</TD>';
	else
		cal += '<TD CLASS="days">' + days_sett[index] + '</TD>';
}

cal += '</TR><TR>';
for(index=0; index < num_days; index++) {
		var yesterday_tomorrow = today - (day-index);
		var this_month = days_month[month];
	if (day == index)
		cal += '<TD CLASS="numbers_days_s">' + today + '</TD>';
	else if (yesterday_tomorrow < this_month+1 & yesterday_tomorrow > 0)
		cal += '<TD CLASS="numbers_days">' + yesterday_tomorrow + '</TD>';
	else
		cal += '<TD CLASS="numbers_days"></TD>';
}

cal += '</TR></TABLE>';
document.getElementById("cal").innerHTML = cal;
setTimeout("my_cal()",1000);
}

function init(){
updateClock();
setInterval("updateClock();", 1000);

my_cal();
}