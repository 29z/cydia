var updateWeatherEvery = updateInterval*60*1000;
var xmldata = false;
var postal;
var refreshLocationTimer;
var updateTimer = 0;
var zip;
var Level = "";
var State = "";

$.ajaxSetup({
cache: false,
headers: {'Cache-Control': 'no-cache'}
});

window.addEventListener("load", function() { 
	document.body.style.width='100%';
    document.body.style.height='100%';
}, false);

switch (lang) {
case "fr":
	var days = ["Dim","Lun","Mar","Mer","Jeu","Ven","Sam"];
	var months=['Janvier','Fevrier','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Decembre'];
break;
case "de":
	var days = ["Son","Mon","Die","Mit","Don","Fre","Sam"];
	var months=["Januar","Februar","Marz","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];
break;
case "sp":
	var days = ["Dom","Lun","Mar","Mie","Jue","Vie","Sab"];
	var months=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
break;
case "it":
	var days = ["Dom","Lun","Mar","Mer","Gio","Ven","Sab"];
	var months=['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'];
break;
default: 
	var days = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
	var months=["January","February","March","April","May","June","July","August","September","October","November","December"];
break;
}

function ForecastDayNames(day) {
switch (day) {
    case "Sun": { return days[0]; }
    case "Mon": { return days[1]; }
    case "Tue": { return days[2]; }
    case "Wed": { return days[3]; }
    case "Thu": { return days[4]; }
    case "Fri": { return days[5]; }
    case "Sat": { return days[6]; }
    case "Today": { return "Today"; }
    case "Tonight": { return "Tonight"; }
	}
}

function updateClock() { 
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
var currentYear = currentTime.getFullYear();
timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

if (Clock == "24h") {
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
       document.getElementById("hour").innerHTML = currentHours;
       document.getElementById("minute").innerHTML = currentMinutes;
       document.getElementById("ampm").innerHTML = timeOfDay;
	}
if (Clock == "12h") {
	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
       document.getElementById("hour").innerHTML = currentHours;
       document.getElementById("minute").innerHTML = currentMinutes;
       document.getElementById("ampm").innerHTML = timeOfDay;
}

document.getElementById("weekday").innerHTML = days[currentTime.getDay()];
document.getElementById("date").innerHTML = currentDate;
document.getElementById("month").innerHTML = months[currentTime.getMonth()];
document.getElementById("year").innerHTML = currentYear;

if (currentTime.getTime() - updateTimer >= updateWeatherEvery) {
	if (updateTimer == 0) {
		if (gps == true) { UpdateLocation(); } else { validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal); }
		} else {
		weatherRefresherTemp(zip);
		}
	updateTimer = currentTime.getTime();
	}
}

function init(){
document.getElementById("cityname").innerHTML = "Wait Dude!!";

updateClock();
setInterval("updateClock();", 1000);

refreshLocationTimer = setTimeout(init, 10*1000);

jQuery.get('file:///private/var/mobile/Library/BatteryStats.txt', function(appdata) {

var myvar = appdata;
var substr = appdata.split('\n');
var Level=substr[0].split(':')[1];
var State=substr[1].split(':')[1];

if( Level > 0 && Level <= 5 ) document.getElementById("BatteryImage").src="Bateria/1.png";
if( Level > 5 && Level <= 10 ) document.getElementById("BatteryImage").src="Bateria/2.png";
if( Level > 10 && Level <= 15 ) document.getElementById("BatteryImage").src="Bateria/3.png";
if( Level > 15 && Level <= 20 ) document.getElementById("BatteryImage").src="Bateria/4.png";
if( Level > 20 && Level <= 25 ) document.getElementById("BatteryImage").src="Bateria/5.png";
if( Level > 25 && Level <= 30 ) document.getElementById("BatteryImage").src="Bateria/6.png";
if( Level > 30 && Level <= 35 ) document.getElementById("BatteryImage").src="Bateria/7.png";
if( Level > 35 && Level <= 40 ) document.getElementById("BatteryImage").src="Bateria/8.png";
if( Level > 40 && Level <= 45 ) document.getElementById("BatteryImage").src="Bateria/9.png";
if( Level > 45 && Level <= 50 ) document.getElementById("BatteryImage").src="Bateria/10.png";
if( Level > 50 && Level <= 55 ) document.getElementById("BatteryImage").src="Bateria/11.png";
if( Level > 55 && Level <= 60 ) document.getElementById("BatteryImage").src="Bateria/12.png";
if( Level > 60 && Level <= 65 ) document.getElementById("BatteryImage").src="Bateria/13.png";
if( Level > 65 && Level <= 70 ) document.getElementById("BatteryImage").src="Bateria/14.png";
if( Level > 70 && Level <= 75 ) document.getElementById("BatteryImage").src="Bateria/15.png";
if( Level > 75 && Level <= 80 ) document.getElementById("BatteryImage").src="Bateria/16.png";
if( Level > 80 && Level <= 85 ) document.getElementById("BatteryImage").src="Bateria/17.png";
if( Level > 85 && Level <= 90 ) document.getElementById("BatteryImage").src="Bateria/18.png";
if( Level > 90 && Level <= 95 ) document.getElementById("BatteryImage").src="Bateria/19.png";
if( Level > 95 && Level <= 100 ) document.getElementById("BatteryImage").src="Bateria/20.png";

document.getElementById("LevelDisplay").innerHTML = Level +"%";
document.getElementById("StateDisplay").innerHTML = State;
});
}

function setPostal(obj){
	if (obj.error == false){
		if(obj.cities.length > 0) {
			postal = escape(obj.cities[0].zip).replace(/^%u/g, "%")
			convertWoeid();
			}
			else
			{
			document.getElementById("cityname").innerHTML="Locale ?!";
			}
		}
		else
		{
		document.getElementById("cityname").innerHTML="Locale ?!";
		setTimeout('validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal)', Math.round(1000*60*5));
		}
}

function weatherRefresherTemp(zip){
	fetchWeatherData(dealWithWeather, zip);
}

function validateWeatherLocation (location, callback) {
	var obj = {error:false, errorString:null, cities: new Array};
	obj.cities[0] = {zip: location};
	callback (obj);
}

function dealWithWeather(obj){
	if (obj.error == false){
	    document.getElementById("cityname").innerHTML=obj.city;
		document.getElementById("weatherIcon").src="Imagenes/"+iconSet+"/"+obj.icon+".png";
		document.getElementById("desc").innerHTML=obj.description;	
		
		if (tempUnit == "c"){
		document.getElementById("temp").innerHTML = obj.temp + "&#176;C";}
	    if (tempUnit == "f"){
		document.getElementById("temp").innerHTML = obj.temp + "&#176;F";}

		document.getElementById("Day1").innerHTML=ForecastDayNames(obj.Day1);
		document.getElementById("Day1Icon").src="Imagenes/"+iconSet+"/"+obj.Day1Code+".png";
		document.getElementById("Day1HiLo").innerHTML=obj.Day1Lo+ "&#176;/ "+obj.Day1Hi+ "&#176;";
		document.getElementById("Day2").innerHTML=ForecastDayNames(obj.Day2);
		document.getElementById("Day2Icon").src="Imagenes/"+iconSet+"/"+obj.Day2Code+".png";
		document.getElementById("Day2HiLo").innerHTML=obj.Day2Lo+ "&#176;/ "+obj.Day2Hi+ "&#176;";
}
}

function findChild (element, nodeName) {
	var child;
	for (child = element.firstChild; child != null; child = child.nextSibling)
	{
		if (child.nodeName == nodeName)
			return child;
	}
	return null;
}

function convertWoeid () {
		var url = "http://weather.yahooapis.com/forecastrss?w="+postal+"&u=f";
		$.get(url, function(data) {
		zip = $(data).find('guid').text().split('_')[0];
		weatherRefresherTemp(zip);
		});
}

function fetchWeatherData (callback, zip) {
	var url="http://xml.weather.yahoo.com/forecastrss/"+zip+"&u="+tempUnit+"&d=5.xml";
	var xml_request = new XMLHttpRequest();
	var requestTimer = setTimeout(function() {
	xml_request.abort();
	if (xmldata == false) { callback ({error:true}); } else {
	document.getElementById("coordinates").className = "TextColorRed"; 
	document.getElementById("coordinates").innerHTML = "[Offline]"; }
    }, 10000);
	xml_request.onload = function(e) {
	clearTimeout(requestTimer);
	xml_loaded(e, xml_request, callback);
	}
	xml_request.overrideMimeType("text/xml");
	xml_request.open("GET", url);
	xml_request.setRequestHeader("Cache-Control", "no-cache");
	xml_request.send(null);
	return xml_request;
}

function xml_loaded (event, request, callback) {
	if (request.responseXML)
	{
		var obj = {error:false, errorString:null};
		xmldata = true;
		var effectiveRoot = findChild(findChild(request.responseXML, "rss"), "channel");
		if (gps == false) {
		if (city == "") { obj.city = findChild(effectiveRoot, "yweather:location").getAttribute("city"); }
		else { obj.city = city }
		} else { obj.city = city; }
		obj.humidity = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("humidity");
		obj.windunit = findChild(effectiveRoot, "yweather:units").getAttribute("speed");		
		obj.winddir = findChild(effectiveRoot, "yweather:wind").getAttribute("direction");
		obj.windspeed = findChild(effectiveRoot, "yweather:wind").getAttribute("speed");	
		obj.visibility = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("visibility");	
		obj.visibilityunit = findChild(effectiveRoot, "yweather:units").getAttribute("distance");
		obj.sunrise = findChild(effectiveRoot, "yweather:astronomy").getAttribute("sunrise");
		obj.sunset = findChild(effectiveRoot, "yweather:astronomy").getAttribute("sunset");
		obj.chill = findChild(effectiveRoot, "yweather:wind").getAttribute("chill");
		obj.realFeel = findChild(effectiveRoot, "yweather:wind").getAttribute("chill");
		var conditionTag = findChild(findChild(effectiveRoot, "item"), "yweather:condition");
		obj.temp = conditionTag.getAttribute("temp");
		obj.icon = conditionTag.getAttribute("code");
		obj.description = conditionTag.getAttribute("text");
		var forecast = findChild(findChild(effectiveRoot, "item"), "yweather:forecast");
		obj.todaylow = forecast.getAttribute("low");
		obj.todayhigh = forecast.getAttribute("high");
		if (obj.description == "Unknown") {
			obj.description = forecast.getAttribute("text");
			obj.icon = forecast.getAttribute("code");
		}
		if (obj.icon == 3200) obj.icon = 48;
		
		obj.Day1 = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("day");
		obj.Day1Hi = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("high");
		obj.Day1Lo = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("low");
		obj.Day1Code = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("code");
		
		obj.Day2 = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("day");
		obj.Day2Hi = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("high");
		obj.Day2Lo = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("low");
		obj.Day2Code = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("code");

		callback (obj); 
	}
	else
	{
		callback ({error:true, errorString:"XML request failed. no responseXML"});
	}
}