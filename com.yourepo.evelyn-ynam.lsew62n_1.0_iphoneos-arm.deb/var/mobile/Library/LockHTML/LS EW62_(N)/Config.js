/*
Configurations
Credits: original code by Dacal & Junesiphone, slightly modified by Evelyn
*/

var Clock = "12h";  // choose between "12h" or "24h"
var Lang = "en";   // choose between "en", "ca", "fr", "de", "it", or "cz"

//Widget position with notifications//
var ShiftUp_Notif = "-30";   // -ve value to shift up. +ve value to shift down.
var OriginalPos = "0";    // shift up or down widget elements besides battery.
