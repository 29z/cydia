var updateWeatherEvery = updateInterval*60*1000;
var xmldata = false;
var postal;
var refreshLocationTimer;
var updateTimer = 0;
var zip;
var TextColor = 'TextColorWhite';

function updateClock() {
                var objToday = new Date(),
                dayOfWeek = weekday[objToday.getDay()],
                dayOfMonth = objToday.getDate(),
                curMonth = months[objToday.getMonth()],
                curHour = objToday.getHours(),
                curMinute = objToday.getMinutes() < 10 ? '0' + objToday.getMinutes() : objToday.getMinutes(),
                //curSeconds = objToday.getSeconds() < 10 ? '0' + objToday.getSeconds() : objToday.getSeconds(),
                curMeridiem = objToday.getHours() < 12 ? 'AM' : 'PM';

                if (xhour == false) {
                    curHour = (curHour < 10 ? '0' : '') + curHour;
                } else {
                    curHour = (curHour > 12) ? curHour - 12 : curHour;
                    curHour = (curHour == 0) ? 12 : curHour;
                }

                $('#time').html(curHour + ':' + curMinute);

                if (ampm == true) {

                    if (lang == 'en') $('#date').html(dayOfWeek + ', ' + curMonth + ' ' + dayOfMonth + ' ' + curMeridiem);
                    else $('#date').html(dayOfWeek + ', ' + dayOfMonth + '. ' + curMonth + ' ' + curMeridiem);

                } else {

                    if (lang == 'en') $('#date').html(dayOfWeek + ', ' + curMonth + ' ' + dayOfMonth);
                    else $('#date').html(dayOfWeek + ', ' + dayOfMonth + '. ' + curMonth);

                }

                if (objToday.getTime() - updateTimer >= updateWeatherEvery) {
                if (updateTimer == 0) {
		            if (gps == true) { UpdateLocation(); } else { validateWeatherLocation(escape(locale).replace(/^%u/g, '%'), setPostal); }
                } else {
                weatherRefresherTemp(zip);
                }
        updateTimer = objToday.getTime();
       }
}

function init() {
                document.getElementById('city').className = TextColor;
                document.getElementById('city').innerHTML = 'Loading...';
                document.getElementById('overlay').src = 'images/' + OvSet + '.png';

                if (colors == 'Black') {
                    document.getElementById('line').src = 'images/lineblack.png';
                    $('.TextColorWhite').css('color', '#000');
                    $('#city').css('color', '#000');
                    $('#desc').css('color', '#000');
                    $('#temp').css('color', '#000');
                    $('#highlowtemp').css('color', '#000');
                    $('#time').css('color', '#000');
                    $('#date').css('color', '#000');
                }
                else {
                    document.getElementById('line').src = 'images/linewhite.png';
                }

                if (design == 'No_conditions') { //hide desc
                    $('#desc').hide();
                    $('#weathericon').hide();
                    $('#line').css('height', '75px');
                    $('#overlay').css('height', '110px');
                }
                // Small_conditions = design in css file
                else if (design == 'Big_icon_on_bottom') {  //icon on bottom
                    $('#city').css('text-align', 'right');
                    $('#city').css('left', '-132px');
                    $('#city').css('top', '97px');
                    $('#weathericon').css('top', '72px');
                    $('#weathericon').css('height', '70px');
                    $('#weathericon').css('width', '70px');
                    $('#desc').css('top', '118px');
                    $('#line').css('height', '120px');
                    $('#overlay').css('height', '150px');
                }
                else if (design == 'Big_icon_on_top') { //icon on top
                    $('#city').css('text-align', 'right');
                    $('#city').css('left', '-132px');
                    $('#city').css('top', '97px');
                    $('#temp').css('top', '69px');
                    $('#temp').css('font-size', '42px');
                    $('#highlowtemp').css('top', '115px');
                    $('#weathericon').css('top', '11px');
                    $('#weathericon').css('height', '70px');
                    $('#weathericon').css('width', '70px');
                    $('#desc').css('top', '118px');
                    $('#line').css('height', '120px');
                    $('#overlay').css('height', '150px');
                }
               

    updateClock();
    setInterval(updateClock, 1000);
}

function setPostal(obj) {
	if (obj.error == false){
		if(obj.cities.length > 0) {
			postal = escape(obj.cities[0].zip).replace(/^%u/g, '%')
			convertWoeid();
			}
			else
			{
			document.getElementById('city').innerHTML='Locale ?!';
			}
		}
		else
		{
		document.getElementById('city').innerHTML='Locale ?!';
		setTimeout('validateWeatherLocation(escape(locale).replace(/^%u/g, '%'), setPostal)', Math.round(1000*60*5));
		}
}

function weatherRefresherTemp(zip){
	fetchWeatherData(dealWithWeather, zip);
}

function validateWeatherLocation (location, callback) {
	var obj = {error:false, errorString:null, cities: new Array};
	obj.cities[0] = {zip: location};
	callback (obj);
}

function dealWithWeather(obj) {
	if (obj.error == false){
	    document.getElementById('city').className= TextColor;
	    document.getElementById('city').innerHTML = obj.city;
		document.getElementById('desc').innerHTML = WeatherDesc[obj.icon]; //translation
		document.getElementById('temp').innerHTML = obj.temp + '\u00B0';
		document.getElementById('highlowtemp').innerHTML = '\u2191' + obj.todayhigh + '\u00B0' + ' ' + '\u2193' + obj.todaylow + '\u00B0';
        
		if ( gps == true) {
		document.getElementById('coordinates').className = 'TextColorWhite';
		document.getElementById('coordinates').innerHTML = ' [' + textLat + ' ' + textLong + ']';
		} else {
		document.getElementById('coordinates').innerHTML = ' ';
	    }

		document.getElementById('weathericon').src = 'images/' + iconSet + '/' + obj.icon + '.png';
	}
	else
	{
	document.getElementById('city').innerHTML = 'Internet ?!';
	}
}

function findChild (element, nodeName) {
	var child;
	for (child = element.firstChild; child != null; child = child.nextSibling)
	{
		if (child.nodeName == nodeName)
			return child;
	}
	return null;
}

function convertWoeid () {
		var url = 'http://weather.yahooapis.com/forecastrss?w='+postal+'&u=f';
		$.get(url, function(data) {
		zip = $(data).find('guid').text().split('_')[0];
		weatherRefresherTemp(zip);
		});
}

// Get data with woeid (no GPS)
function fetchWeatherData (callback, zip) {
	var url='http://xml.weather.yahoo.com/forecastrss/' + zip + '_' + tempUnit + '.xml';
	var xml_request = new XMLHttpRequest();
	var requestTimer = setTimeout(function() {
	xml_request.abort();
	if (xmldata == false) { callback ({error:true}); } else {
	document.getElementById('coordinates').style.color = 'red'; 
	document.getElementById('coordinates').innerHTML = '[Offline]'; }
    }, 10000);
	xml_request.onload = function(e) {
	clearTimeout(requestTimer);
	xml_loaded(e, xml_request, callback);
	}
	xml_request.overrideMimeType('text/xml');
	xml_request.open('GET', url);
	xml_request.setRequestHeader('Cache-Control', 'no-cache');
	xml_request.send(null);
	return xml_request;
}

function xml_loaded (event, request, callback) {
	if (request.responseXML)
	{
		var obj = {error:false, errorString:null};
		xmldata = true;
		var effectiveRoot = findChild(findChild(request.responseXML, 'rss'), 'channel');
		if (gps == false) {
		if (city == '') { obj.city = findChild(effectiveRoot, 'yweather:location').getAttribute('city'); }
		else { obj.city = city }
		} else { obj.city = city; }
		
		var conditionTag = findChild(findChild(effectiveRoot, 'item'), 'yweather:condition');
		obj.temp = conditionTag.getAttribute('temp');
		obj.icon = conditionTag.getAttribute('code');
		obj.description = conditionTag.getAttribute('text');
		var forecast = findChild(findChild(effectiveRoot, 'item'), 'yweather:forecast');
		obj.todaylow = forecast.getAttribute('low');
		obj.todayhigh = forecast.getAttribute('high');
		if (obj.description == 'Unknown') {
		    obj.description = forecast.getAttribute('text');
			obj.icon = forecast.getAttribute('code');
		}
		if (obj.icon == 3200) obj.icon = 48;
			    
		
		callback (obj); 
	}
	else
	{
		callback ({error:true, errorString:'XML request failed. no responseXML'});
	}
}