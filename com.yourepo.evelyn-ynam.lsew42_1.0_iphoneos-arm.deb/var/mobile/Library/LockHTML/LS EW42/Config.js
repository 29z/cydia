/*
Configuration here!
Credits: Code originally by Dacal & Schnedi
*/

var Clock = "12h";	       // choose between "12h" or "24h".
var lang = "en";		   // choose between "sp", "en", "de", or "fr".

var gps = false;	       // Requires WidgetWeather2.
var locale = 2165352;		// Yahoo Weather (used it if gps does not work).
var tempUnit = "c";	       // choose between "c" or "f".
var iconSet = "Outlined";  // Do not modify.
var updateInterval = 30;   // in minutes

//Widget position with notifications//
var ShiftUp_Notif = "-10";   // -ve value to shift up. +ve value to shift down.
var OriginalPos = "10";    // shift up or down widget elements besides battery.

/*
Options below are for specific situations.
*/

var UseCityGPS = false;        // If your city is innacurate with Yahoo, you can try to use the GPS localization (if available).
var UseNeighborhood = false;	   // If your city is inaccurate with GPS localization, you can try to use the neighborhood (or state).