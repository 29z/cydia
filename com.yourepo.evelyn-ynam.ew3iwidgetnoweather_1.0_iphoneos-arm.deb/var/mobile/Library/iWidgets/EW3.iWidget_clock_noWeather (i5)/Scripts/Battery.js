var Level = "";

$.ajaxSetup({
cache: false,
headers: {'Cache-Control': 'no-cache'}
});

function init() {

refreshLocationTimer = setTimeout(init, 10*1000);

jQuery.get('file:///var/mobile/Library/Stats/BatteryStats.txt', function(appdata) {

var myvar = appdata;
var substr = appdata.split('\n');
var Level=substr[0].split(':')[1];
var State=substr[1].split(':')[1];


if (lang == "sp"){
	document.getElementById("Battery").innerHTML = "Bateria" + " restante";
	document.getElementById("LevelDisplay").innerHTML = Level + "%";}
if (lang == "en"){
	document.getElementById("Battery").innerHTML = "Battery" + " remaining";
	document.getElementById("LevelDisplay").innerHTML = Level + "%";}
if (lang == "fr"){
	document.getElementById("Battery").innerHTML = "Batterie" + " restant";
	document.getElementById("LevelDisplay").innerHTML = Level + "%";}
if (lang == "de"){
	document.getElementById("Battery").innerHTML = "Batterie" + " &uuml;brig";
	document.getElementById("LevelDisplay").innerHTML = Level + "%";}
if (lang == "it"){
	document.getElementById("Battery").innerHTML = "Batteria"; + " rimanente"
	document.getElementById("LevelDisplay").innerHTML = Level + "%";}
});
}