/* 
Configurations
Credits: original code by Dacal, Junesiphone & Matchstic, modified by Evelyn
*/

var Clock = "12h";  // choose between "12h" or "24h"
var Lang = "en";   // choose between "en", "ca", "fr", "de", "it", or "cz"

var weathercode = 'HKXX0075';  // get weather code from www.weather.com, search for your city, code can be found in address bar.
var celsius = true;
var gpsswitch = false;
var refreshrate = 10;   // update interval of weather, in minutes
var IconSet = "Outlined";   // choose your icon pack here
