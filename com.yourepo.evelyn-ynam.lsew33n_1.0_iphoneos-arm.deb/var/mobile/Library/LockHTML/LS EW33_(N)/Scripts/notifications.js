window.addEventListener("load", function() { 
    document.body.style.width='100%';
    document.body.style.height='100%';
}, false);

function notif(){
    if (groovyAPI.isShowingNotifications()){
        $('#Clock').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#Clock').animate({opacity: '0.5'}, 500);
        $('#ampm').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#ampm').animate({opacity: '0.5'}, 500);
        $('#Cal').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#R').animate({opacity: '0'}, 500);
    } else {
        $('#Clock').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#Clock').animate({opacity: '0.3'}, 500);
        $('#ampm').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#ampm').animate({opacity: '0.3'}, 500);
        $('#Cal').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#R').animate({opacity: '0.9'}, 500);
    }

    setTimeout(notif, 1000);      
};

notif();