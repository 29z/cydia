var updateWeatherEvery = updateInterval*60*1000;
var xmldata = false;
var postal;
var refreshLocationTimer;
var updateTimer = 0;
var zip;

window.addEventListener("load", function() { 
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);

switch (lang) {
case "fr":
	var days = ["Dim","Lun","Mar","Mer","Jeu","Ven","Sam"];
	var months=['Janvier','Fevrier','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Decembre'];
break;
case "de":
	var days = ["Son","Mon","Die","Mit","Don","Fre","Sam"];
	var months=["Januar","Februar","Marz","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];
break;
case "sp":
	var days = ["Dom","Lun","Mar","Mie","Jue","Vie","Sab"];
	var months=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
break;
case "it":
	var days = ["Dom","Lun","Mar","Mer","Gio","Ven","Sab"];
	var months=['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'];
break;
default: 
	var days = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
	var months=["January","February","March","April","May","June","July","August","September","October","November","December"];
break;
}

function ForecastDayNames(day) {
switch (day) {
    case "Sun": { return days[0]; }
    case "Mon": { return days[1]; }
    case "Tue": { return days[2]; }
    case "Wed": { return days[3]; }
    case "Thu": { return days[4]; }
    case "Fri": { return days[5]; }
    case "Sat": { return days[6]; }
    case "Today": {
	if (lang == "sp"){ return "Hoy"; }
	if (lang == "en"){ return "Today"; }
	if (lang == "fr"){ return "Aujourd'hui"; }
	if (lang == "de"){ return "Heute"; }
	if (lang == "it"){ return "Oggi"; }
	}
    case "Tonight": { return "Tonight"; }
	}
}

function updateClock() { 
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
var currentYear = currentTime.getFullYear();
timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

if (Clock == "24h") {
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
       document.getElementById("hour").innerHTML = currentHours;
       document.getElementById("minute").innerHTML = currentMinutes;
       document.getElementById("ampm").innerHTML = timeOfDay;
	}
if (Clock == "12h") {
	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
       document.getElementById("hour").innerHTML = currentHours;
       document.getElementById("minute").innerHTML = currentMinutes;
       document.getElementById("ampm").innerHTML = timeOfDay;
}

document.getElementById("weekday").innerHTML = days[currentTime.getDay()];
document.getElementById("date").innerHTML = currentDate;
document.getElementById("month").innerHTML = months[currentTime.getMonth()];
document.getElementById("year").innerHTML = currentYear;

if (currentTime.getTime() - updateTimer >= updateWeatherEvery) {
	if (updateTimer == 0) {
		if (gps == true) { UpdateLocation(); } else { validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal); }
		} else {
		weatherRefresherTemp(zip);
		}
	updateTimer = currentTime.getTime();
	}
}

function init(){
document.getElementById("cityname").innerHTML = "Wait Dude!!";

updateClock();
setInterval("updateClock();", 1000);
}

function setPostal(obj){
	if (obj.error == false){
		if(obj.cities.length > 0) {
			postal = escape(obj.cities[0].zip).replace(/^%u/g, "%")
			convertWoeid();
			}
			else
			{
			document.getElementById("cityname").innerHTML="Locale ?!";
			}
		}
		else
		{
		document.getElementById("cityname").innerHTML="Locale ?!";
		setTimeout('validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal)', Math.round(1000*60*5));
		}
}

function weatherRefresherTemp(zip){
	fetchWeatherData(dealWithWeather, zip);
}

function validateWeatherLocation (location, callback) {
	var obj = {error:false, errorString:null, cities: new Array};
	obj.cities[0] = {zip: location};
	callback (obj);
}

function dealWithWeather(obj){
	if (obj.error == false){
	    document.getElementById("cityname").innerHTML=obj.city;
		document.getElementById("temp").innerHTML = obj.temp + "&#176;";
		document.getElementById("weatherIcon").src="Imagenes/"+iconSet+"/"+obj.icon+".png";
		document.getElementById("desc").innerHTML=obj.description;

		document.getElementById("Today").innerHTML=ForecastDayNames("Today");

		document.getElementById("Day1").innerHTML=ForecastDayNames(obj.Day1);
		document.getElementById("Day1Icon").src="Imagenes/"+iconSet+"/"+obj.Day1Code+".png";
		document.getElementById("Day1Hi").innerHTML=obj.Day1Hi+ "&#176;";
		document.getElementById("Day2").innerHTML=ForecastDayNames(obj.Day2);
		document.getElementById("Day2Icon").src="Imagenes/"+iconSet+"/"+obj.Day2Code+".png";
		document.getElementById("Day2Hi").innerHTML=obj.Day2Hi+ "&#176;";
		document.getElementById("Day3").innerHTML=ForecastDayNames(obj.Day3);
		document.getElementById("Day3Icon").src="Imagenes/"+iconSet+"/"+obj.Day3Code+".png";
		document.getElementById("Day3Hi").innerHTML=obj.Day3Hi+ "&#176;";	
		document.getElementById("Day4").innerHTML=ForecastDayNames(obj.Day4);
		document.getElementById("Day4Icon").src="Imagenes/"+iconSet+"/"+obj.Day4Code+".png";
		document.getElementById("Day4Hi").innerHTML=obj.Day4Hi+ "&#176;";		
}
}

function findChild (element, nodeName) {
	var child;
	for (child = element.firstChild; child != null; child = child.nextSibling)
	{
		if (child.nodeName == nodeName)
			return child;
	}
	return null;
}

function convertWoeid () {
		var url = "http://weather.yahooapis.com/forecastrss?w="+postal+"&u=f";
		$.get(url, function(data) {
		zip = $(data).find('guid').text().split('_')[0];
		weatherRefresherTemp(zip);
		});
}

function fetchWeatherData (callback, zip) {
	var url="http://xml.weather.yahoo.com/forecastrss/"+zip+"&u="+tempUnit+"&d=5.xml";
	var xml_request = new XMLHttpRequest();
	var requestTimer = setTimeout(function() {
	xml_request.abort();
	if (xmldata == false) { callback ({error:true}); } else {
	document.getElementById("coordinates").className = "TextColorRed"; 
	document.getElementById("coordinates").innerHTML = "[Offline]"; }
    }, 10000);
	xml_request.onload = function(e) {
	clearTimeout(requestTimer);
	xml_loaded(e, xml_request, callback);
	}
	xml_request.overrideMimeType("text/xml");
	xml_request.open("GET", url);
	xml_request.setRequestHeader("Cache-Control", "no-cache");
	xml_request.send(null);
	return xml_request;
}

function xml_loaded (event, request, callback) {
	if (request.responseXML)
	{
		var obj = {error:false, errorString:null};
		xmldata = true;
		var effectiveRoot = findChild(findChild(request.responseXML, "rss"), "channel");
		if (gps == false) {
		if (city == "") { obj.city = findChild(effectiveRoot, "yweather:location").getAttribute("city"); }
		else { obj.city = city }
		} else { obj.city = city; }
		obj.humidity = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("humidity");
		obj.windunit = findChild(effectiveRoot, "yweather:units").getAttribute("speed");		
		obj.winddir = findChild(effectiveRoot, "yweather:wind").getAttribute("direction");
		obj.windspeed = findChild(effectiveRoot, "yweather:wind").getAttribute("speed");	
		obj.visibility = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("visibility");	
		obj.visibilityunit = findChild(effectiveRoot, "yweather:units").getAttribute("distance");
		obj.sunrise = findChild(effectiveRoot, "yweather:astronomy").getAttribute("sunrise");
		obj.sunset = findChild(effectiveRoot, "yweather:astronomy").getAttribute("sunset");
		obj.chill = findChild(effectiveRoot, "yweather:wind").getAttribute("chill");
		obj.realFeel = findChild(effectiveRoot, "yweather:wind").getAttribute("chill");
		var conditionTag = findChild(findChild(effectiveRoot, "item"), "yweather:condition");
		obj.temp = conditionTag.getAttribute("temp");
		obj.icon = conditionTag.getAttribute("code");
		obj.description = conditionTag.getAttribute("text");
		var forecast = findChild(findChild(effectiveRoot, "item"), "yweather:forecast");
		obj.todaylow = forecast.getAttribute("low");
		obj.todayhigh = forecast.getAttribute("high");
		if (obj.description == "Unknown") {
			obj.description = forecast.getAttribute("text");
			obj.icon = forecast.getAttribute("code");
		}
		if (obj.icon == 3200) obj.icon = 48

        obj.Day0 = request.responseXML.getElementsByTagName("forecast")[0].getAttribute("day");
		
		obj.Day1 = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("day");
		obj.Day1Hi = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("high");
		obj.Day1Lo = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("low");
		obj.Day1Code = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("code");
		
		obj.Day2 = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("day");
		obj.Day2Hi = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("high");
		obj.Day2Lo = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("low");
		obj.Day2Code = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("code");
		
		obj.Day3 = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("day");
		obj.Day3Hi = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("high");
		obj.Day3Lo = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("low");
		obj.Day3Code = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("code");
		
		obj.Day4 = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("day");
		obj.Day4Hi = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("high");
		obj.Day4Lo = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("low");
		obj.Day4Code = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("code");

		callback (obj); 
	}
	else
	{
		callback ({error:true, errorString:"XML request failed. no responseXML"});
	}
}