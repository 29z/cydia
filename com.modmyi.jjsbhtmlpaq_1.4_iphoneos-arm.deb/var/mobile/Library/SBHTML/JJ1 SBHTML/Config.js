/*
Configuration here !
Code by Dacal -- Modified by Schnedi  // D0 NOT REMOVE THIS LINE //
For weather code, go to http://weather.yahoo.com/ and search for your city. The correct zip code is in the URL (only numbers)
*/

var Clock = "24h";	       // choose between "12h" or "24h".
var lang = "sp";	           // choose between "sp", "en", "de", "fr" or "it".

var gps = false; 	       // Requires WidgetWeather2.
var locale = 766537;	       // Yahoo Weather (used if gps set to false or myLocation.txt file not found).
var tempUnit = "c";	       // choose between "c" or "f".
var iconSet = "Outlined";  // Do not modify.
var updateInterval = 30;   // in minutes

/*
Options below are for specific situations.
*/

var UseCityGPS = false;        // If your city is innacurate with Yahoo, you can try to use the GPS localization (if available).
var UseNeighborhood = false;	   // If your city is inaccurate with GPS localization, you can try to use the neighborhood (or state).