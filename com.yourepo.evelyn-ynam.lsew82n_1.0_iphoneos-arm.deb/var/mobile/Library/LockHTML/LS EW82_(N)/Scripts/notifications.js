window.addEventListener("load", function() { 
    document.body.style.width='100%';
    document.body.style.height='100%';
}, false);

function notif(){
    if (groovyAPI.isShowingNotifications()){
        $('#Up').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#Down').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#Cal').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#weekday').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#Clock').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
    } else {
        $('#Up').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#Down').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#Cal').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#weekday').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#Clock').animate({'margin-top': OriginalPos + "%",}, 500);
    }

    setTimeout(notif, 1000);      
};

notif();