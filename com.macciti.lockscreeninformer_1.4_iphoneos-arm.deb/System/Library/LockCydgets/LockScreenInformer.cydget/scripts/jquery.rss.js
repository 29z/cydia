/*
                                                                                
                                                                        M~M.    
                                MMM.            MM.                    MM.M     
                      .MM      MMMM           MMMMMM                 IMMMMM     
      MM~             .MNMMM           M        MM             MMM     MM       
     MM MMM.           MM .M=   MM    MM MM.    MM            MM :M,   MM       
    MM. ZMM M.        :MD .MM   MM M. MMMMM  M.+MM .M         MM  MM   MM       
    MM  MM? M         ?MM MM    M$.M  MMMMM N. ~M$.M         .MM  M    MM       
    MM  MMMM          DMMMM.    MMM   MM .MM    MMM+          .MMM    .MM       
     MMM              MM                        ~M.                    MM       
                      MM                                                        
                                                                                
     .      .     .           ..         .   ..               ..    ..    ..    
    MMMMMMMMM.  .MMMMMMMMM   .MMMMMM7   DMMMMM,           MMMMMM   .MMMMMMM.    
    MMMMMMMMM.  MMMMMMMMMM   .MM  MM,   DMMMMM,           MMMMMM  ~MMMMMMM      
    MMMMMMMMMM  MMMMMMMMMM   $M.  ,MM   DMMMMM,           MMMMMM MMMMMMMM       
    MMMMMMMMMM. MMMMMMMMMM  .MMMMMMNM   DMMMMM,           MMMMMMMMMMMMMM        
    MMMMMMMMMMMMMMMMMMMMMM  NM MMMMMMM  DMMMMM,           MMMMMMMMMMMMM.        
    MMMMMMMMMMMMMMMMMMMMMM  MMMMMMMMMM  DMMMMM,           MMMMMMMMMMMI          
    MMMMMMMMMMMMMMMMMMMMMM  MMMMMMMMIM  DMMMMM,           MMMMMMMMMMM.          
    MMMMMMDMMMMMMMM.MMMMMM  MMMMMMMMIM  DMMMMM,           MMMMMMMMMMMM,         
    MMMMMM MMMMMMMM MMMMMM  MMMMMMMMIM  DMMMMM,           MMMMMMMMMMMMM~        
    MMMMMM MMMMMMMM MMMMMM  MMMMMMMMIM  DMMMMM~           MMMMMMMMMMMMMM,       
    MMMMMM  MMMMMM  MMMMMM  MMMMMMMMIM  DMMMMMMMMMMMMMM   MMMMMM  MMMMMMM=      
    MMMMMM  MMMMMM  MMMMMM  MMMMMMMMIM  DMMMMMMMMMMMMMM.  MMMMMM   MMMMMMM$     
    MMMMMM  MMMMM   MMMMMM  MMZ77777MM. DMMMMMMMMMMMMMM.  MMMMMM    MMMMMMMN    
     MMMM   ,DMM=   7MMMM.  .?MMMMMMM    MMMMMMMMMMMMM    =MMMM.    .$MMMMM.    

Thank you for purchasing this LockScreen theme, "LockScreen Informer".
Whilst we can not prevent you stealing this code, redistributing it or giving
it to your mates. We would appreciate you actually purchased it from the Cydia
store. This way, we can devote time to supporting, upgrading and adding
additional features. If you have stolen this script, please either purchase
it from the Cydia store or buy us a coffee. PayPal: payment@apintofmilk.com.

This is version 1.4
Support at: http://themes.apintofmilk.com/support/
                                                                                
*/

!function(e){"use strict";var t=function(t,n,i,o){this.target=t,this.url=n,this.html=[],this.effectQueue=[],this.options=e.extend({ssl:!1,limit:null,key:null,layoutTemplate:'<ul class="rssentries">{entries}</ul>',entryTemplate:'<li><span class="newsheadline">{title}</span><br /><span class="newscontent">{shortBodyPlain}</span></li>',tokens:{},outputMode:"json",effect:"show",error:function(){console.log("Error: URL doesn't link to RSS-Feed")},success:function(){}},i||{}),this.callback=o||this.options.success};t.htmlTags=["doctype","html","head","title","base","link","meta","style","script","noscript","body","article","nav","aside","section","header","footer","h1-h6","hgroup","address","p","hr","pre","blockquote","ol","ul","li","dl","dt","dd","figure","figcaption","div","table","caption","thead","tbody","tfoot","tr","th","td","col","colgroup","form","fieldset","legend","label","input","button","select","datalist","optgroup","option","textarea","keygen","output","progress","meter","details","summary","command","menu","del","ins","img","iframe","embed","object","param","video","audio","source","canvas","track","map","area","a","em","strong","i","b","u","s","small","abbr","q","cite","dfn","sub","sup","time","code","kbd","samp","var","mark","bdi","bdo","ruby","rt","rp","span","br","wbr"],t.prototype.load=function(t){var n="http"+(this.options.ssl?"s":""),i=n+"://ajax.googleapis.com/ajax/services/feed/load",o=i+"?v=1.0&output="+this.options.outputMode+"&callback=?&q="+encodeURIComponent(this.url);null!=this.options.limit&&(o+="&num="+this.options.limit),null!=this.options.key&&(o+="&key="+this.options.key),e.getJSON(o,t)},t.prototype.render=function(){var t=this;this.load(function(n){try{t.feed=n.responseData.feed,t.entries=n.responseData.feed.entries}catch(i){return t.entries=[],t.feed=null,t.options.error.call(t)}var o=t.generateHTMLForEntries();t.target.append(o.layout),0!==o.entries.length&&t.appendEntriesAndApplyEffects(e("entries",o.layout),o.entries),t.effectQueue.length>0?t.executeEffectQueue(t.callback):e.isFunction(t.callback)&&t.callback.call(t)})},t.prototype.appendEntriesAndApplyEffects=function(t,n){var i=this;e.each(n,function(e,n){var o=i.wrapContent(n);"show"===i.options.effect?t.before(o):(o.css({display:"none"}),t.before(o),i.applyEffect(o,i.options.effect))}),t.remove()},t.prototype.generateHTMLForEntries=function(){var t=this,n={entries:[],layout:null};return e(this.entries).each(function(){var e=this;if(t.isRelevant(e)){var i=t.evaluateStringForEntry(t.options.entryTemplate,e);n.entries.push(i)}}),n.layout=this.wrapContent(this.options.entryTemplate?this.options.layoutTemplate.replace("{entries}","<entries></entries>"):"<div><entries></entries></div>"),n},t.prototype.wrapContent=function(t){return e(0!==e.trim(t).indexOf("<")?"<div>"+t+"</div>":t)},t.prototype.applyEffect=function(e,t,n){var i=this;switch(t){case"slide":e.slideDown("slow",n);break;case"slideFast":e.slideDown(n);break;case"slideSynced":i.effectQueue.push({element:e,effect:"slide"});break;case"slideFastSynced":i.effectQueue.push({element:e,effect:"slideFast"})}},t.prototype.executeEffectQueue=function(e){var t=this;this.effectQueue.reverse();var n=function(){var i=t.effectQueue.pop();i?t.applyEffect(i.element,i.effect,n):e&&e()};n()},t.prototype.evaluateStringForEntry=function(t,n){var i=t,o=this;return e(t.match(/(\{.*?\})/g)).each(function(){var e=this.toString();i=i.replace(e,o.getValueForToken(e,n))}),i},t.prototype.isRelevant=function(e){var t=this.getTokenMap(e);return this.options.filter?this.options.filterLimit&&this.options.filterLimit==this.html.length?!1:this.options.filter(e,t):!0},t.prototype.getTokenMap=function(n){if(!this.feedTokens){var i=JSON.parse(JSON.stringify(this.feed));delete i.entries,this.feedTokens=i}return e.extend({feed:this.feedTokens,url:n.link,author:n.author,date:n.publishedDate,title:n.title,body:n.content,shortBody:n.contentSnippet,bodyPlain:function(e){for(var n=e.content.replace(/<script[\\r\\\s\S]*<\/script>/gim,"").replace(/<\/?[^>]+>/gi,""),i=0;i<t.htmlTags.length;i++)n=n.replace(new RegExp("<"+t.htmlTags[i],"gi"),"");return n}(n),shortBodyPlain:n.contentSnippet.replace(/<\/?[^>]+>/gi,""),index:e.inArray(n,this.entries),totalEntries:this.entries.length,teaserImage:function(e){try{return e.content.match(/(<img.*?>)/gi)[0]}catch(t){return""}}(n),teaserImageUrl:function(e){try{return e.content.match(/(<img.*?>)/gi)[0].match(/src="(.*?)"/)[1]}catch(t){return""}}(n)},this.options.tokens)},t.prototype.getValueForToken=function(e,t){var n=this.getTokenMap(t),i=e.replace(/[\{\}]/g,""),o=n[i];if("undefined"!=typeof o)return"function"==typeof o?o(t,n):o;throw new Error("Unknown token: "+e)},e.fn.rss=function(e,n,i){return new t(this,e,n,i).render(),this}}(jQuery);