/*
                                                                                
                                                                        M~M.    
                                MMM.            MM.                    MM.M     
                      .MM      MMMM           MMMMMM                 IMMMMM     
      MM~             .MNMMM           M        MM             MMM     MM       
     MM MMM.           MM .M=   MM    MM MM.    MM            MM :M,   MM       
    MM. ZMM M.        :MD .MM   MM M. MMMMM  M.+MM .M         MM  MM   MM       
    MM  MM? M         ?MM MM    M$.M  MMMMM N. ~M$.M         .MM  M    MM       
    MM  MMMM          DMMMM.    MMM   MM .MM    MMM+          .MMM    .MM       
     MMM              MM                        ~M.                    MM       
                      MM                                                        
                                                                                
     .      .     .           ..         .   ..               ..    ..    ..    
    MMMMMMMMM.  .MMMMMMMMM   .MMMMMM7   DMMMMM,           MMMMMM   .MMMMMMM.    
    MMMMMMMMM.  MMMMMMMMMM   .MM  MM,   DMMMMM,           MMMMMM  ~MMMMMMM      
    MMMMMMMMMM  MMMMMMMMMM   $M.  ,MM   DMMMMM,           MMMMMM MMMMMMMM       
    MMMMMMMMMM. MMMMMMMMMM  .MMMMMMNM   DMMMMM,           MMMMMMMMMMMMMM        
    MMMMMMMMMMMMMMMMMMMMMM  NM MMMMMMM  DMMMMM,           MMMMMMMMMMMMM.        
    MMMMMMMMMMMMMMMMMMMMMM  MMMMMMMMMM  DMMMMM,           MMMMMMMMMMMI          
    MMMMMMMMMMMMMMMMMMMMMM  MMMMMMMMIM  DMMMMM,           MMMMMMMMMMM.          
    MMMMMMDMMMMMMMM.MMMMMM  MMMMMMMMIM  DMMMMM,           MMMMMMMMMMMM,         
    MMMMMM MMMMMMMM MMMMMM  MMMMMMMMIM  DMMMMM,           MMMMMMMMMMMMM~        
    MMMMMM MMMMMMMM MMMMMM  MMMMMMMMIM  DMMMMM~           MMMMMMMMMMMMMM,       
    MMMMMM  MMMMMM  MMMMMM  MMMMMMMMIM  DMMMMMMMMMMMMMM   MMMMMM  MMMMMMM=      
    MMMMMM  MMMMMM  MMMMMM  MMMMMMMMIM  DMMMMMMMMMMMMMM.  MMMMMM   MMMMMMM$     
    MMMMMM  MMMMM   MMMMMM  MMZ77777MM. DMMMMMMMMMMMMMM.  MMMMMM    MMMMMMMN    
     MMMM   ,DMM=   7MMMM.  .?MMMMMMM    MMMMMMMMMMMMM    =MMMM.    .$MMMMM.    

Thank you for purchasing this LockScreen theme, "LockScreen Informer".
Whilst we can not prevent you stealing this code, redistributing it or giving
it to your mates. We would appreciate you actually purchased it from the Cydia
store. This way, we can devote time to supporting, upgrading and adding
additional features. If you have stolen this script, please either purchase
it from the Cydia store or buy us a coffee. PayPal: payment@apintofmilk.com.

This is version 1.4
Support at: http://themes.apintofmilk.com/support/
                                                                                
*/

!function(e){e.fn.extend({tweecool:function(t){function a(e){var t=new Date,a=Date.parse(t),r=Date.parse(e),n=(a-r)/1e3,o=1,i=60,s=3600,l=86400,u=604800,h=2592e3,m=31536e3;return n>o&&i>n?Math.round(n/o)+" seconds ago":n>=i&&s>n?Math.round(n/i)+" minutes ago":n>=s&&l>n?Math.round(n/s)+" hours ago":n>=l&&u>n?Math.round(n/l)+" days ago":n>=u&&h>n?Math.round(n/u)+" weeks ago":n>=h&&m>n?Math.round(n/h)+" months ago":"over a year ago"}var r={username:"themesbymilk",limit:1,profile_image:!1,show_time:!0},t=e.extend(r,t);return this.each(function(){var r=t,n=e(this),o=e("<ul>").appendTo(n),i=/(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/gi;e.getJSON("http://api.tweecool.com/?screenname="+r.username+"&count="+r.limit,function(t){if(t.errors||null==t)return n.html("Sorry, no tweets available."),!1;if(r.profile_image)var s='<a href="https://twitter.com/'+r.username+'" target="_blank"><img src="'+t.user.profile_image_url+'" alt="'+r.username+'" /></a>';else s="";e.each(t.tweets,function(e,t){if(r.show_time)var n=a(t.created_at);else var n="";o.append("<li>"+s+'<div class="tweets_txt">'+t.text.replace(i,"$1")+" <span>"+n+"</span></div></li>")})}).fail(function(){n.html("Sorry, no tweets available")})})}})}(jQuery);